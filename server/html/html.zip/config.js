window.ipConfigUrl = {
  baseURL: 'http://192.168.40.6:8000',
};
